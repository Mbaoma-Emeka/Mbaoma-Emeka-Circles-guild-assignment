function sayHello() {
  alert("Hello from your static site!");
}
